# Cryptographic Discovery — Advanced Enterprise Test Repository

Synthetic repository designed to stress-test an enterprise cryptographic discovery,
risk scoring, certificate inventory, dependency analysis, and post-quantum migration UI.

## Intended scanner findings

This fixture intentionally contains a mixture of modern, legacy, weak, deprecated,
and quantum-vulnerable cryptography.

### Critical candidates
- RSA-1024
- DSA-1024
- MD5 signatures / fingerprints
- RC4
- DES / 3DES
- TLS 1.0 / TLS 1.1
- `alg: none` JWT configuration
- hard-coded test private-key material
- weak 512-bit DH parameters

### High / migration candidates
- RSA-2048
- RSA-PSS
- ECDSA P-256
- ECDH P-256
- DH-2048
- Ed25519
- AES-128-CBC
- SHA-1

### Lower-risk / modern references
- AES-256-GCM
- ChaCha20-Poly1305
- SHA-256 / SHA-384 / SHA-512

## Quantum-risk model

RSA, DSA, ECDSA, ECDH and finite-field Diffie-Hellman are public-key primitives that
should be treated as quantum-vulnerable for migration planning because sufficiently
capable quantum computers running Shor's algorithm can undermine their mathematical
assumptions. Symmetric algorithms such as AES are affected differently; Grover-style
speedups reduce the effective search margin, so AES-256 is generally preferred for a
stronger long-term margin.

This repository contains **synthetic test artifacts only**. Do not use any generated key
or certificate in a real environment.
