package com.example.security;

public class CertificateScanner {
    String[] certificates = {
        "certs/rsa1024-legacy.pem",
        "certs/rsa2048-server.pem",
        "certs/ecdsa-p256-server.pem",
        "certs/dsa1024-legacy.pem",
        "certs/md5-signature-test.pem"
    };
}
