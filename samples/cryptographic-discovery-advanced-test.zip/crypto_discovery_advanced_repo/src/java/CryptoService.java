package com.example.security;

import java.security.*;
import javax.crypto.*;

public class CryptoService {
    public void discover() throws Exception {
        KeyPairGenerator rsa1024 = KeyPairGenerator.getInstance("RSA");
        rsa1024.initialize(1024);
        KeyPairGenerator rsa2048 = KeyPairGenerator.getInstance("RSA");
        rsa2048.initialize(2048);
        KeyPairGenerator dsa = KeyPairGenerator.getInstance("DSA");
        dsa.initialize(1024);

        Signature md5rsa = Signature.getInstance("MD5withRSA");
        Signature sha1rsa = Signature.getInstance("SHA1withRSA");
        Signature pss = Signature.getInstance("RSASSA-PSS");
        Signature ecdsa = Signature.getInstance("SHA256withECDSA");

        Cipher des = Cipher.getInstance("DES/ECB/PKCS5Padding");
        Cipher tripleDes = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        Cipher aesCbc = Cipher.getInstance("AES/CBC/PKCS5Padding");
        Cipher aesGcm = Cipher.getInstance("AES/GCM/NoPadding");

        MessageDigest md5 = MessageDigest.getInstance("MD5");
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
    }
}
