package com.example.security;

public class LegacyTLS {
    String protocol = "TLSv1";
    String protocol11 = "TLSv1.1";
    String ciphers = "RC4-SHA:DES-CBC3-SHA:AES128-SHA";
    String signature = "RSA-SHA1";
}
