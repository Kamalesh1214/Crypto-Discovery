package com.example.security;

public class QuantumInventory {
    String[] classicalPublicKeyAlgorithms = {
        "RSA-1024", "RSA-2048", "DSA-1024", "ECDSA-P256",
        "ECDH-P256", "DH-512", "DH-2048", "Ed25519"
    };
    String[] migrationStatus = {"inventory", "hybrid-test", "replacement"};
}
