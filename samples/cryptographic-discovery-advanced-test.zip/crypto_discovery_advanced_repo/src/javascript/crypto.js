const crypto = require('crypto');

const legacy = {
  hash: 'md5',
  hash2: 'sha1',
  cipher: 'des-ede3-cbc',
  stream: 'rc4',
  rsaBits: 1024,
  ecCurve: 'prime256v1'
};

const modern = {
  hash: 'sha256',
  cipher: 'aes-256-gcm',
  curve: 'prime256v1'
};

module.exports = { legacy, modern };
