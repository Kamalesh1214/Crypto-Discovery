const jwt = require('jsonwebtoken');

const weakHeader = { alg: 'none', typ: 'JWT' };
const rsaHeader = { alg: 'RS256', typ: 'JWT' };
const ecHeader = { alg: 'ES256', typ: 'JWT' };

// Scanner should flag acceptance of alg=none as critical.
module.exports = { weakHeader, rsaHeader, ecHeader };
