import hashlib
from Crypto.Cipher import DES, DES3, ARC4

# Deliberately unsafe examples for discovery testing.
def legacy_digest(data):
    return hashlib.md5(data).hexdigest()

def legacy_digest_sha1(data):
    return hashlib.sha1(data).hexdigest()

def legacy_stream(key, data):
    return ARC4.new(key).encrypt(data)

def legacy_des(key, data):
    return DES.new(key, DES.MODE_ECB).encrypt(data)

def legacy_3des(key, data):
    return DES3.new(key, DES3.MODE_ECB).encrypt(data)
