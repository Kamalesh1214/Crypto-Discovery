from cryptography.hazmat.primitives.asymmetric import rsa, ec, dsa, dh, ed25519
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes

ALGORITHMS = {
    "RSA": [1024, 2048, 3072],
    "DSA": [1024],
    "ECDSA": ["P-256", "P-384"],
    "ECDH": ["P-256", "P-384"],
    "DH": [512, 2048],
    "Ed25519": [256],
    "AES": [128, 256],
    "3DES": [168],
    "DES": [56],
    "RC4": [128],
    "ChaCha20-Poly1305": [256],
    "SHA-1": [],
    "SHA-256": [],
    "SHA-384": [],
    "SHA-512": [],
    "MD5": [],
}

# Quantum migration inventory: public-key systems are the primary concern.
QUANTUM_VULNERABLE = ["RSA", "DSA", "ECDSA", "ECDH", "DH", "Ed25519"]

print(ALGORITHMS)
