# Password storage examples for a scanner fixture.
LEGACY_PASSWORD_HASH = "MD5"
LEGACY_PASSWORD_HASH_2 = "SHA1"
RECOMMENDED_PASSWORD_KDF = "Argon2id"
