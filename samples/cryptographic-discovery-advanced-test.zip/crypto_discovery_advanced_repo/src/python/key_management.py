# Synthetic test fixture. Values are non-production placeholders.
RSA_KEY_SIZE = 1024
DSA_KEY_SIZE = 1024
DH_PARAMETER_SIZE = 512
ECDH_CURVE = "secp256r1"
ECDSA_CURVE = "secp256r1"

PRIVATE_KEY_PATHS = [
    "keys/test-rsa-1024.pem",
    "keys/test-ecdsa-p256.pem",
    "keys/test-dsa-1024.pem",
]
