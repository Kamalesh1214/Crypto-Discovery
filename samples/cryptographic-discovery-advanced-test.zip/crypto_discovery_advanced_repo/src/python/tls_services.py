import ssl

legacy = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
legacy.minimum_version = ssl.TLSVersion.TLSv1
legacy.maximum_version = ssl.TLSVersion.TLSv1_1
legacy.set_ciphers("RC4-SHA:DES-CBC3-SHA:AES128-SHA")

modern = ssl.create_default_context()
modern.minimum_version = ssl.TLSVersion.TLSv1_2
modern.set_ciphers("ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384")
