# Certificate Inventory

- certs/rsa1024-legacy.pem — RSA 1024, SHA-1, legacy
- certs/rsa2048-server.pem — RSA 2048, SHA-256, classical public-key / quantum migration candidate
- certs/ecdsa-p256-server.pem — ECDSA P-256, classical public-key / quantum migration candidate
- certs/dsa1024-legacy.pem — DSA 1024, legacy and quantum-vulnerable
- certs/md5-signature-test.pem — synthetic MD5/RSA legacy artifact
