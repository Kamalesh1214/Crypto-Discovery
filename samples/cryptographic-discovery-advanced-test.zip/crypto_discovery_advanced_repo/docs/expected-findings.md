# Expected Findings

A capable scanner should discover substantially more than 10 artifacts.

| Category | Examples | Suggested severity |
|---|---|---|
| Broken/obsolete | MD5, RC4, DES, 3DES, DSA-1024, RSA-1024 | CRITICAL |
| Deprecated protocol | TLS 1.0, TLS 1.1 | CRITICAL/HIGH |
| Weak key exchange | DH-512 | CRITICAL |
| Weak authentication | JWT `alg=none` | CRITICAL |
| Legacy crypto | SHA-1, AES-128-CBC | HIGH |
| Quantum migration | RSA, ECDSA, ECDH, DSA, DH | HIGH |
| Modern crypto | AES-256-GCM, ChaCha20-Poly1305, SHA-384 | LOW/INFO |

The exact score is intentionally left to the consuming application.
