# Quantum Migration Inventory

## Directly vulnerable classical public-key families

1. RSA-1024 / RSA-2048
2. DSA-1024
3. ECDSA P-256
4. ECDH P-256
5. DH-512 / DH-2048
6. Ed25519

These should be treated as migration candidates even when they are not currently
cryptographically broken by conventional computers.

## Suggested prioritization

- CRITICAL: weak/deprecated primitives and protocols that are already unsafe.
- HIGH: classical public-key primitives requiring post-quantum migration planning.
- MEDIUM: legacy symmetric modes and reduced-size keys requiring modernization.
- LOW/INFO: modern algorithms such as AES-256-GCM and SHA-384.
