package com.example.security;

import java.security.MessageDigest;
import java.security.KeyPairGenerator;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;

public class CryptoService {
    public void discoverAlgorithms() throws Exception {
        KeyPairGenerator rsa = KeyPairGenerator.getInstance("RSA");
        rsa.initialize(2048);

        KeyPairGenerator ec = KeyPairGenerator.getInstance("EC");

        Signature ecdsa = Signature.getInstance("SHA256withECDSA");
        Signature rsaPss = Signature.getInstance("RSASSA-PSS");

        KeyAgreement ecdh = KeyAgreement.getInstance("ECDH");

        Cipher aesGcm = Cipher.getInstance("AES/GCM/NoPadding");
        Cipher aesCbc = Cipher.getInstance("AES/CBC/PKCS5Padding");

        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        MessageDigest legacySha1 = MessageDigest.getInstance("SHA-1");

        System.out.println("RSA-2048, ECDSA-P256, ECDH, AES-GCM, AES-CBC, SHA-256, SHA-1");
    }
}
