package com.example.security;

import javax.crypto.KeyAgreement;
import javax.crypto.spec.DHParameterSpec;

public class DiffieHellmanExample {
    private static final int DH_SIZE = 2048;

    public void initialize() throws Exception {
        DHParameterSpec parameters = new DHParameterSpec(
            new java.math.BigInteger("FFFFFFFFFFFFFFFF", 16),
            new java.math.BigInteger("02", 16),
            DH_SIZE
        );
        KeyAgreement agreement = KeyAgreement.getInstance("DiffieHellman");
        System.out.println("DH-2048 configured");
    }
}
