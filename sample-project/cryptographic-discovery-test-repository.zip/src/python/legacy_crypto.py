# Legacy cryptography intentionally included for risk detection.

LEGACY_HASH = "SHA1"
LEGACY_SIGNATURE = "RSA-SHA1"
LEGACY_CIPHER = "AES-128-CBC"

def legacy_fingerprint(data: bytes):
    import hashlib
    return hashlib.sha1(data).hexdigest()
