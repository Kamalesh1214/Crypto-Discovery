import ssl

context = ssl.create_default_context()

# Synthetic enterprise TLS policy.
context.minimum_version = ssl.TLSVersion.TLSv1_2
context.set_ciphers(
    "ECDHE-RSA-AES256-GCM-SHA384:"
    "ECDHE-ECDSA-AES256-GCM-SHA384:"
    "AES256-SHA"
)

# Certificate and key artifacts referenced by the service.
CERTIFICATE_FILE = "certs/server-rsa2048.pem"
PRIVATE_KEY_FILE = "certs/server-rsa2048-key.pem"
ECDSA_CERTIFICATE_FILE = "certs/server-ecdsa-p256.pem"
