from cryptography.hazmat.primitives.asymmetric import rsa, ec, dh
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# Synthetic examples for discovery scanners.

RSA_KEY_SIZE = 2048
RSA_SIGNATURE = "RSA-PSS"

ELLIPTIC_CURVE = "secp256r1"
ECDSA_SIGNATURE = "ECDSA-SHA256"
ECDH_EXCHANGE = "ECDH"

DH_PARAMETER_SIZE = 2048

SYMMETRIC_ALGORITHM = "AES-256-GCM"
LEGACY_SYMMETRIC_ALGORITHM = "AES-128-CBC"

HASH_ALGORITHM = "SHA-256"
LEGACY_HASH_ALGORITHM = "SHA-1"

def inventory():
    return {
        "public_key": ["RSA-2048", "ECDSA-P256", "ECDH-P256", "DH-2048"],
        "symmetric": ["AES-256-GCM", "AES-128-CBC"],
        "hashes": ["SHA-256", "SHA-1"],
        "quantum_priority": ["RSA-2048", "ECDSA-P256", "ECDH-P256", "DH-2048"]
    }
