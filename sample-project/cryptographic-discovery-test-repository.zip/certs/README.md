These PEM files are synthetic placeholders, not usable production certificates or keys.

Discovery targets:
- server-rsa2048.pem -> RSA certificate artifact
- server-ecdsa-p256.pem -> ECDSA/P-256 certificate artifact
- server-rsa2048-key.pem -> private-key-like artifact

A production scanner should inspect certificate metadata such as:
subject, issuer, validity, public-key algorithm, public-key size/curve, signature algorithm,
and certificate chain relationships.
