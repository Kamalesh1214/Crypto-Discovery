# Enterprise Cryptographic Discovery — Sample Repository

This repository is intentionally designed as a test fixture for a cryptographic discovery
and post-quantum risk analysis tool.

It contains:
- Cryptographic algorithms: RSA, ECDSA, ECDH, Diffie-Hellman, AES-GCM, AES-CBC, SHA-256, SHA-1
- Certificate artifacts in PEM format
- Java and Python source files
- Dependency manifests
- TLS configuration
- Key/configuration references
- Deliberately weak/legacy algorithms that should be flagged
- Quantum-vulnerable public-key cryptography that should be prioritized for migration

Expected discovery examples:
- RSA-2048 / RSA signatures
- ECDSA P-256
- ECDH P-256
- DH-2048
- AES-256-GCM
- AES-128-CBC
- SHA-1
- TLS configuration using RSA/ECDSA certificates

Post-quantum note:
RSA, ECDSA, ECDH and finite-field Diffie-Hellman are generally considered vulnerable
to sufficiently capable cryptographically relevant quantum computers because Shor's
algorithm can break their underlying public-key assumptions. AES and SHA-2 are not
broken in the same way; Grover-style speedups affect their security margins, so key/hash
sizes matter.

This is synthetic test data. The certificates are intentionally non-production fixtures.
