# Expected Findings

## Cryptographic artifacts

| Artifact | Algorithm | Example use | Quantum relevance |
|---|---|---|---|
| server-rsa2048.pem | RSA-2048 | TLS certificate | HIGH / migration candidate |
| server-ecdsa-p256.pem | ECDSA P-256 | TLS certificate | HIGH / migration candidate |
| crypto_inventory.py | RSA-2048 | public-key crypto | HIGH |
| crypto_inventory.py | ECDSA-P256 | signing | HIGH |
| crypto_inventory.py | ECDH-P256 | key exchange | HIGH |
| DiffieHellmanExample.java | DH-2048 | key exchange | HIGH |
| crypto_inventory.py | AES-256-GCM | encryption | Lower quantum concern; retain with policy review |
| legacy_crypto.py | SHA-1 | hashing | Legacy / collision risk |
| legacy_crypto.py | AES-128-CBC | encryption | Legacy / configuration review |

## Important distinction

A quantum risk flag should not mean that a quantum computer can break the algorithm today.
The intended classification is exposure to future cryptographically relevant quantum attacks.

Shor's algorithm threatens RSA, elliptic-curve cryptography and finite-field Diffie-Hellman.
Grover's algorithm gives a quadratic search speedup against generic symmetric-key/hash
search problems, so AES-256 has a substantially stronger margin than AES-128.

## Suggested scanner fields

- algorithm
- primitive
- key size / curve
- usage
- file
- line
- certificate subject
- certificate issuer
- validity period
- signature algorithm
- quantum vulnerable: yes/no
- severity
- migration priority
