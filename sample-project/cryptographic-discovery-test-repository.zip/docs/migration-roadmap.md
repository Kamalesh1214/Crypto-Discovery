# Post-Quantum Migration Test Data

Priority 1:
- Inventory RSA, ECDSA, ECDH and DH usage.
- Locate certificates, keys and TLS endpoints.
- Map each artifact to an owner/application.

Priority 2:
- Identify protocol and library constraints.
- Test hybrid key-establishment approaches where supported.
- Plan replacement of classical public-key certificates and key exchange.

Priority 3:
- Review AES key sizes and hash algorithms.
- Remove SHA-1 and other deprecated primitives.
- Establish cryptographic-agility controls.

This document is a synthetic roadmap for testing discovery/reporting features.
